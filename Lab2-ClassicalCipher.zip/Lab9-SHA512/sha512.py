import hashlib
import hmac

def calculate_hmac_sha512(message: str, key: str) -> str:
    # Convert the key and message to bytes
    key_bytes = key.encode('utf-8')
    message_bytes = message.encode('utf-8')

    # Create the HMAC object
    hmac_obj = hmac.new(key_bytes, message_bytes, hashlib.sha512)

    # Return the HMAC digest in hexadecimal format
    return hmac_obj.hexdigest()

# Example usage
message = "This is a variable-length message."
key = "mysecretkey"

mac = calculate_hmac_sha512(message, key)
print(f"Message: {message}")
print(f"Key: {key}")
print(f"MAC (HMAC-SHA-512): {mac}")
