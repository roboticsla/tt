import hashlib
import hmac
import time
import random
import string

def generate_random_message(size_in_bits):
    size_in_bytes = size_in_bits // 8
    return ''.join(random.choices(string.ascii_letters + string.digits, k=size_in_bytes))

def calculate_hmac(message, key, hash_algorithm):
    key_bytes = key.encode('utf-8')
    message_bytes = message.encode('utf-8')
    hmac_obj = hmac.new(key_bytes, message_bytes, hash_algorithm)
    return hmac_obj.hexdigest()

def measure_time(hash_algorithm, message_size_bits, key):
    message = generate_random_message(message_size_bits)
    start_time = time.time()
    calculate_hmac(message, key, hash_algorithm)
    end_time = time.time()
    return end_time - start_time

def main():
    key = "supersecretkey"
    hash_algorithms = {
        "SHA-256": hashlib.sha256,
        "SHA-384": hashlib.sha384,
        "SHA-512": hashlib.sha512,
    }
    message_sizes = [512, 1024, 2048, 4096]  # Message sizes in bits

    results = []

    for hash_name, hash_algo in hash_algorithms.items():
        for size in message_sizes:
            time_taken = measure_time(hash_algo, size, key)
            results.append((hash_name, size, time_taken))

    print(f"{'Hash Algorithm':<15}{'Message Size (bits)':<20}{'Time (seconds)':<15}")
    print("-" * 50)
    for hash_name, size, time_taken in results:
        print(f"{hash_name:<15}{size:<20}{time_taken:<15.8f}")

if __name__ == "__main__":
    main()

