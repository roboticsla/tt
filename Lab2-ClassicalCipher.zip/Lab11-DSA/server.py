import asyncio
import websockets
import random

# Function to compute modular inverse
def mod_inverse(a, m):
    m0, x0, x1 = m, 0, 1
    if m == 1:
        return 0
    while a > 1:
        q = a // m
        m, a = a % m, m
        x0, x1 = x1 - q * x0, x0
    return x1 + m0 if x1 < 0 else x1

# Simple custom hash function (basic checksum)
def simple_hash(message):
    return sum(ord(char) for char in message)

# Get parameters (fixed values)
p = 23  # Prime number
q = 11  # Another prime number
g = 4   # Generator

# Generate private key (x) and public key (y)
x = random.randint(1, q-1)  # Private key
y = pow(g, x, p)            # Public key

# Sign the message using the custom hash function
def sign_message(message):
    k = random.randint(1, q-1)  # Random integer
    r = pow(g, k, p) % q
    k_inv = mod_inverse(k, q)  # Modular inverse of k mod q
    h = simple_hash(message) % q  # Custom hash of the message
    s = (k_inv * (h + x * r)) % q
    return (r, s)

# WebSocket handler
async def handle_client(websocket, path):
    try:
        # Send public key to client
        await websocket.send(str(y))
        
        while True:
            # Receive a message from the client
            message = await websocket.recv()
            
            # If the message is None or the connection is closed, break out
            if message is None:
                break

            print(f"Received message: {message}")
            
            # Generate signature for the message
            signature = sign_message(message)
            
            # Send the signature (r, s) back to the client
            await websocket.send(f"{signature[0]},{signature[1]}")
            
    except websockets.exceptions.ConnectionClosed:
        print("Connection closed by the client.")
    finally:
        # Close the WebSocket connection gracefully
        await websocket.close()

# Start the WebSocket server
async def main():
    server = await websockets.serve(handle_client, "localhost", 65432)
    print("Server started at ws://localhost:65432")
    await server.wait_closed()

if __name__ == "__main__":
    asyncio.run(main())
