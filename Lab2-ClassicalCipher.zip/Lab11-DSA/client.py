import asyncio
import websockets

# Known DSA parameters (must match the server's parameters)
p = int(input("Enter p: "))  # Prime number
q = int(input("Enter q: "))  # Another prime number
g = int(input("Enter g: "))  # Generator

# Simple custom hash function (basic checksum)
def simple_hash(message):
    return sum(ord(char) for char in message)

# Function to compute modular inverse
def mod_inverse(a, m):
    m0, x0, x1 = m, 0, 1
    if m == 1:
        return 0
    while a > 1:
        q = a // m
        m, a = a % m, m
        x0, x1 = x1 - q * x0, x0
    return x1 + m0 if x1 < 0 else x1

# Verify the signature using the custom hash function
def verify_signature(message, r, s, y):
    h = simple_hash(message) % q  # Custom hash of the message
    w = mod_inverse(s, q)         # Inverse of s mod q
    u1 = (h * w) % q
    u2 = (r * w) % q
    v = (pow(g, u1, p) * pow(y, u2, p)) % p % q
    return v == r

# WebSocket client
async def main():
    uri = "ws://localhost:65432"
    
    async with websockets.connect(uri) as websocket:
        # Receive public key from the server
        public_key = await websocket.recv()
        y = int(public_key)  # Convert to integer
        
        message = input("Enter a message: ")
        await websocket.send(message)  # Send the message
        
        # Receive the signature (r, s) from the server
        signature = await websocket.recv()
        r, s = map(int, signature.split(','))
        print(f"Received signature: (r: {r}, s: {s})")
        
        # Verify the signature
        is_valid = verify_signature(message, r, s, y)
        print(f"Signature valid: {is_valid}")

if __name__ == "__main__":
    asyncio.run(main())
