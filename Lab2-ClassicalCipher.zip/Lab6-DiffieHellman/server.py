import asyncio
import websockets

# Diffie-Hellman parameters
q = 17  # Prime number
a = 3   # Primitive root modulo q

async def client():
    uri = "ws://localhost:12345"
    async with websockets.connect(uri) as websocket:
        # Step 1: Calculate Client's public key
        xa = 15  # Client's private key
        ya = pow(a, xa, q)  # Client's public key
        print(f"Client's public key (ya): {ya}")

        # Step 2: Send `ya` to the server
        await websocket.send(str(ya))

        # Step 3: Receive `yb` from the server
        yb = int(await websocket.recv())
        print(f"Client received server's public key (yb): {yb}")

        # Step 4: Compute shared key
        key = pow(yb, xa, q)  # Shared key
        print(f"Client computed shared key: {key}")

asyncio.run(client())
