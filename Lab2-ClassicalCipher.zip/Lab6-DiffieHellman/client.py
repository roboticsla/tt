import asyncio
import websockets

# Diffie-Hellman parameters
q = 17  # Prime number
a = 3   # Primitive root modulo q

async def handler(websocket, path):
    # Step 1: Receive `ya` from Client 1
    ya = int(await websocket.recv())
    print(f"Server received ya: {ya}")

    # Step 2: Calculate the key
    xb = 13  # Server's private key
    yb = pow(a, xb, q)  # Server's public key
    print(f"Server's public key (yb): {yb}")

    # Step 3: Send `yb` to Client 1
    await websocket.send(str(yb))

    # Step 4: Compute shared key
    key = pow(ya, xb, q)  # Shared key
    print(f"Server computed shared key: {key}")

# Main server function
async def main():
    async with websockets.serve(handler, "localhost", 12345):
        print("Server is running on ws://localhost:12345...")
        await asyncio.Future()  # Keep the server running indefinitely

asyncio.run(main())
