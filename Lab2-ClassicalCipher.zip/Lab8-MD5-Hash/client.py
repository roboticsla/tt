import asyncio
import websockets

async def client():
    uri = "ws://127.0.0.1:8765"
    async with websockets.connect(uri) as websocket:
        # Inputs
        message = "Hello, this is a test message."
        key = "secret_key"
        
        # Send data to server (message and key concatenated with "|")
        await websocket.send(f"{message}|{key}")
        
        # Receive MD5 MAC from server
        md5_mac = await websocket.recv()
        print(f"MD5 MAC from server: {md5_mac}")

# Use asyncio.run() to run the coroutine
asyncio.run(client())
