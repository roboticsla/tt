import asyncio
import websockets
import hmac
import hashlib

# Function to generate MD5 MAC
def generate_md5_mac(message, key):
    return hmac.new(key, message, hashlib.md5).hexdigest()

# WebSocket handler
async def handler(websocket, path):
    # Receive data (message and key) from client
    data = await websocket.recv()  # Expects a message like "message|key"
    message, key = data.split("|")
    
    # Convert to bytes
    message = message.encode()
    key = key.encode()
    
    # Generate MD5 MAC
    md5_mac = generate_md5_mac(message, key)
    
    # Send MAC back to the client
    await websocket.send(md5_mac)

# Start WebSocket server
start_server = websockets.serve(handler, "127.0.0.1", 8765)

# Run the server
asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()
