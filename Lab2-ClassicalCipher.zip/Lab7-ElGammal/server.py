import asyncio
import websockets
from sympy import mod_inverse

q = 19  # Prime modulus

def decrypt(c1, c2, xa):
    K = pow(c1, xa, q)  # Shared secret
    Kinv = mod_inverse(K, q)  # Modular inverse of K
    message = (c2 * Kinv) % q  # Decrypted message
    return message

async def handler(websocket, path):
    # Receive the ciphertext and public key from the client
    data = await websocket.recv()
    c1, c2, ya = map(int, data.split(';'))

    # Server's private key
    xa = 5

    # Decrypt the message
    message = decrypt(c1, c2, xa)
    print(f"Decrypted message: {message}")

# Main server function
async def main():
    async with websockets.serve(handler, "localhost", 12345):
        print("Server is running on ws://localhost:12345...")
        await asyncio.Future()  # Keep the server running indefinitely

asyncio.run(main())
