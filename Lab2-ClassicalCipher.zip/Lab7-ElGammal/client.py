import asyncio
import websockets

q = 19  # Prime modulus
a = 10  # Base (primitive root modulo q)

def encrypt(message, ya):
    k = 6  # Random session key
    K = pow(ya, k, q)  # Shared secret
    c1 = pow(a, k, q)  # First part of ciphertext
    c2 = (K * message) % q  # Second part of ciphertext
    return c1, c2

async def client():
    uri = "ws://localhost:12345"
    async with websockets.connect(uri) as websocket:
        xa = 5  # Client's private key
        ya = pow(a, xa, q)  # Client's public key
        message = 17  # Message to send

        # Encrypt the message
        c1, c2 = encrypt(message, ya)

        # Send ciphertext and public key to the server
        await websocket.send(f"{c1};{c2};{ya}")
        print(f"Sent: c1={c1}, c2={c2}, ya={ya}")

asyncio.run(client())
