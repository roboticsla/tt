import asyncio
import websockets
from sympy import mod_inverse

p, q = 61, 53
n = p * q
phi = (p - 1) * (q - 1)
e = 17
d = mod_inverse(e, phi)
public_key = (e, n)
private_key = (d, n)

async def encrypt_message(message, public_key_B):
    encrypted_message = ''
    for char in message:
        m = ord(char)
        encrypted_m = pow(m, public_key_B[0], public_key_B[1])
        encrypted_message += f'{encrypted_m} '
    return encrypted_message.strip()

async def sender():
    uri = "ws://localhost:12345"
    async with websockets.connect(uri) as websocket:
        # Receive B's public key
        data = await websocket.recv()
        e_B, n_B = map(int, data.split())
        public_key_B = (e_B, n_B)

        # Message to be sent
        message = 'HELLOWORLDHOWAREYOU'

        # Encrypt the message
        encrypted_message = await encrypt_message(message, public_key_B)

        # Send the encrypted message and A's public key
        await websocket.send(f"{encrypted_message};{public_key[0]};{public_key[1]}")
        print("Encrypted message sent to the server.")

asyncio.run(sender())
