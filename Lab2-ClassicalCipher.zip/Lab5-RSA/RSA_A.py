import asyncio
import websockets
from sympy import mod_inverse

# RSA key generation for B (Receiver)
p, q = 67, 59
n = p * q
phi = (p - 1) * (q - 1)
e = 19
d = mod_inverse(e, phi)
public_key = (e, n)
private_key = (d, n)

async def decrypt_message(encrypted_message):
    decrypted_message = ''
    for encrypted_char in encrypted_message.split():
        c = int(encrypted_char)
        decrypted_m = pow(c, private_key[0], private_key[1])
        decrypted_message += chr(decrypted_m)
    return decrypted_message

async def handler(websocket):
    # Send B's public key to the client
    await websocket.send(f"{public_key[0]} {public_key[1]}")

    # Receive the encrypted message and A's public key
    data = await websocket.recv()
    encrypted_message, e_A, n_A = data.split(";")
    e_A, n_A = int(e_A), int(n_A)

    # Decrypt the received message
    decrypted_message = await decrypt_message(encrypted_message)

    print(f"Decrypted Message: {decrypted_message}")

async def main():
    async with websockets.serve(handler, "localhost", 12345):
        print("Server is running on ws://localhost:12345...")
        await asyncio.Future()  # Run forever

asyncio.run(main())
